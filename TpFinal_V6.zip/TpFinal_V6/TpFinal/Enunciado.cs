﻿


/*
  
Proyecto 2:
 
Un médico tiene registrada la información de los turnos dados en el día:

 nombre paciente y hora de la cita (string hh:mm).

 Los turnos los da cada media hora, entre las 8 y las 12hs(horario del último turno).
 
 Además tiene almacenada a parte  la información de cada uno de sus pacientes:
 
 nombre, dni, obra social (“particular” si no posee),
 nro de afiliado a la obra social (0 si no posee obra social),  diagnóstico.
 
Se deberá desarrollar una aplicación,
 utilizando las clases que crea necesarias,
 que resuelva las funcionalidades que se muestran en el siguiente menú:

		a) Dar turno. Si no hay turnos disponibles se debe levantar
		una excepción avisando lo ocurrido (“horarios no disponibles,
		llamar próximo día de atencion”)
		
		b) Actualizar el diagnóstico de un paciente determinado.
		
		c) Cancelar un  turno dado
		
		d) Listado de turnos dados
		
		e) Listado de obras sociales de los pacientes que atiende el médico (sin repeticiones)
		
		f) Agregar paciente
		
		g) Eliminar paciente
		
		h) Listado de pacientes



public void Arreglar(){
Hola Carlos, hay algunas clase que están de más en tu UML,

 para tu proyecto solo necesitas las clases Medico, Turno y Paciente,
 
 con esas 3 clases podes resolver el trabajo.
 
el médico tiene un array de turnos

el turno tiene un nombre de paciente y la hora del turno

y el paciente tiene nombre, dni,obra social, nro afiliado y diagnóstico
}
 
  */

