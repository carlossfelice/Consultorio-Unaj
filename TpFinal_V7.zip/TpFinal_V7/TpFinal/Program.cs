﻿/*
 * Created by SharpDevelop.
 * User: Carlos
 * Date: 12/10/2022
 * Time: 14:11
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections;
using System.Collections.Generic;

namespace TpFinal
{
	public class Program
	{
		
		public static void Main(string[] args)
		{
			Medico unMedico=new Medico();
			Console.ForegroundColor=ConsoleColor.Cyan;
			Console.WriteLine(
				"///////////////MENU DE OPCIONES//////////////////"+"\n"+
				"1) Agregar turno"+"\n"+
				"2) Eliminar Turno"+"\n"+
				"3) Listado de turnos"+"\n"+
				"4) Listado de obras sociales"+"\n"+
				"5) Agregar paciente"+"\n"+
				"6) Modificar el diagnóstico de un paciente"+"\n"+
				"7) Eliminar paciente"+"\n"+
				"8) Listado de paciente"+"\n"+
				"9) Salida"+"\n"
			);

			int sigue=0;
			Console.WriteLine("Ingrese Opcion: ");
			try{
				sigue=int.Parse(Console.ReadLine());
			}
			catch(Exception e)
			{
				Console.WriteLine("No ingreso un Numero");
				//Console.WriteLine(e);
			}
			while(sigue!=9)
			{
				switch(sigue)
				{
						//**************************turnos********************************************
					case(1):
						Console.Clear();
						Console.WriteLine("*****Agregar Turno*******************");
						unMedico.turnosDisponibles();

						Console.WriteLine("Agregar turno en formato 08:00//08:30//09:30");
						string horaTurno=Console.ReadLine();
						
						Console.WriteLine("Ingrese el nombre del paciente");
						string nombrePaciente=Console.ReadLine();
						unMedico.agregarTurnoOpcion1(horaTurno,nombrePaciente);

						break;
						//***************************************************************************
					case(2):
						Console.Clear();
						Console.WriteLine("*****Eliminar Turno dado************");
						//no utilize el metodo eliminarTurno solo lo desocupo
						Console.WriteLine("Ingrese la hora");
						string hora=Console.ReadLine();
						Console.WriteLine("Ingrese nombre del paciente");
						string nombre=Console.ReadLine();
						
						unMedico.eliminarTurnoOpcion2(hora,nombre);
						
						break;
						
						//************************listadosTurnos**************************************
					case(3):
						Console.Clear();
						Console.WriteLine("******Listado de turnos dados*******");
						unMedico.listadoTurnosOpcion3();
						
						break;
						//***************************************************************************
					case(4):
						Console.Clear();
						Console.WriteLine("*******Listado de obras sociales con los que trabajo*******");
						unMedico.listadoObraSocialOpcion4();
						
						break;
						
						//**********************pacientes**********************************************
					case(5):
						Console.Clear();
						Console.WriteLine("*******Agregar paciente**************");

						Console.WriteLine("Ingresa el nombre: ");
						string nombreP=Console.ReadLine();
						Console.WriteLine("Ingresa el dni: ");
						int dniP=int.Parse(Console.ReadLine());
						Console.WriteLine("Ingresa obraSocial: ");
						string obrasocialP=Console.ReadLine();
						Console.WriteLine("Ingresa nroAfiliado: ");
						int nroP=int.Parse(Console.ReadLine());
						Console.WriteLine("Ingresa diagnostico: ");
						string diagP=Console.ReadLine();

						Paciente unPaciente=new Paciente(nombreP,dniP,obrasocialP,nroP,diagP);
						unMedico.agregarPacienteOpcion5(unPaciente);
						
						break;
						//***************************************************************************
					case(6):
						Console.Clear();
						Console.WriteLine("*******Modificar el diagnóstico de un paciente determinado*******");
						
						Console.WriteLine("Ingrese documento del paciente: ");
						int documento=int.Parse(Console.ReadLine());
						
						Console.WriteLine("Ingresa el diagnostico Nuevo: ");
						string diagnosticoNuevo=Console.ReadLine();
						
						unMedico.modificarDiagnosticoOpcion6(documento,diagnosticoNuevo);
						
						break;
						//***************************************************************************
					case(7):
						Console.Clear();
						Console.WriteLine("*******Eliminar paciente***************");
						
						Console.WriteLine("Ingrese documento de paciente a eliminar: ");
						int documentoEli=int.Parse(Console.ReadLine());
						
						unMedico.eliminarPacienteOpcion7(documentoEli);

						Console.WriteLine("Paciente Eliminado!!");
						
						break;
						//***************************************************************************
					case(8):
						Console.Clear();
						Console.WriteLine("*******Listado de paciente*************");
						
						unMedico.listadoPacienteOpcion8();
						
						break;

					case(9):
						sigue=9;
						break;
					default:
						
						Console.WriteLine("XXXXX Ingresa numero valido!! XXXXXX");
						break;
						
				}
				
				Console.ReadKey();
				Console.Clear();
				
				Console.WriteLine(
					"///////////////MENU DE OPCIONES//////////////////"+"\n"+
					"1) Agregar turno"+"\n"+
					"2) Eliminar Turno"+"\n"+
					"3) Listado de turnos"+"\n"+
					"4) Listado de obras sociales"+"\n"+
					"5) Agregar paciente"+"\n"+
					"6) Modificar el diagnóstico de un paciente"+"\n"+
					"7) Eliminar paciente"+"\n"+
					"8) Listado de paciente"+"\n"+
					"9) Salida"+"\n"
				);
				
				Console.WriteLine("Ingrese nuevamente Otra Opcion:1 al 9");
				try{
					sigue=int.Parse(Console.ReadLine());
				}
				catch(Exception e)
				{
					Console.WriteLine("No ingreso un Numero");
					//Console.WriteLine(e);
				}
				
			}

			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
		
		
	}




}
